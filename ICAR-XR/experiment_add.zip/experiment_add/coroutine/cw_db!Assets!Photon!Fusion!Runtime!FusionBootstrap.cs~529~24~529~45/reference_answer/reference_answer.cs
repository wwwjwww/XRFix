protected IEnumerator StartWithClients(GameMode serverMode, SceneRef sceneRef, int clientCount) {

    if (CurrentStage != Stage.Disconnected) {
        yield break;
    }

    bool includesServerStart = serverMode != GameMode.Shared && serverMode != GameMode.Client && serverMode != GameMode.AutoHostOrClient;

    if (!includesServerStart && clientCount == 0) {
        Debug.LogError($"{nameof(GameMode)} is set to {serverMode}, and {nameof(clientCount)} is set to zero. Starting no network runners.");
        yield break;
    }

    CurrentStage = Stage.StartingUp;

    var currentScene = SceneManager.GetActiveScene();


    if (!RunnerPrefab) {
        Debug.LogError($"{nameof(RunnerPrefab)} not set, can't perform debug start.");
        yield break;
    }


    RunnerPrefab = Instantiate(RunnerPrefab);
    DontDestroyOnLoad(RunnerPrefab);
    RunnerPrefab.name = "Temporary Runner Prefab";


    var config = NetworkProjectConfig.Global;
    if (config.PeerMode != NetworkProjectConfig.PeerModes.Multiple) {
        int maxClientsAllowed = includesServerStart ? 0 : 1;
        if (clientCount > maxClientsAllowed) {
            Debug.LogWarning($"Instance mode must be set to {nameof(NetworkProjectConfig.PeerModes.Multiple)} to perform a debug start multiple peers. Restricting client count to {maxClientsAllowed}.");
            clientCount = maxClientsAllowed;
        }
    }



    var localMultipeerCheck = (serverMode == GameMode.Shared || serverMode == GameMode.AutoHostOrClient || serverMode == GameMode.Server || serverMode == GameMode.Host) &&
    clientCount     > 1                                                                                                                        &&
    config.PeerMode == NetworkProjectConfig.PeerModes.Multiple;
    var isMppmMainInstance = FusionMppm.Status == FusionMppmStatus.MainInstance;

    if ((localMultipeerCheck || isMppmMainInstance) && string.IsNullOrEmpty(DefaultRoomName)) {
        DefaultRoomName = Guid.NewGuid().ToString();
        Debug.Log($"Generated Session Name: {DefaultRoomName}");
    }

    if (gameObject.transform.parent) {
        Debug.LogWarning($"{nameof(FusionBootstrap)} can't be a child game object, un-parenting.");
        gameObject.transform.parent = null;
    }

    DontDestroyOnLoad(gameObject);
    CurrentServerMode = serverMode;


    if (includesServerStart) {
        _server = Instantiate(RunnerPrefab);
        _server.name = serverMode.ToString();

        var serverTask = InitializeNetworkRunner(_server, serverMode, NetAddress.Any(ServerPort), sceneRef, (runner) => {
            #if FUSION_DEV
            var name = _server.name; // closures do not capture values, need a local var to save it
            Debug.Log($"Server NetworkRunner '{name}' started.");
            #endif
        });

        var waitForSecondsRealtime = new WaitForSecondsRealtime(VirtualInstanceConnectDelay);
        var waitForSeconds = new WaitForSeconds(1f);

        while (serverTask.IsCompleted == false) {
            yield return waitForSeconds;
        }

        if (serverTask.IsFaulted) {
            Log.Debug($"Unable to start server: {serverTask.Exception}");

            ShutdownAll();
            yield break;
        }


        yield return StartClients(clientCount, serverMode, sceneRef);
    } else {
        yield return StartClients(clientCount, serverMode, sceneRef);
    }

    if (FusionMppm.Status == FusionMppmStatus.MainInstance && serverMode != GameMode.Single) {
        if (VirtualInstanceConnectDelay > 0) {
            yield return waitForSecondsRealtime;
        }
        FusionMppm.MainEditor?.Send(new StartCommand {
            RoomName = DefaultRoomName,
            InitialScene = sceneRef,
            ClientCount =  1,
            IsShared = serverMode == GameMode.Shared
        });
    }
}
