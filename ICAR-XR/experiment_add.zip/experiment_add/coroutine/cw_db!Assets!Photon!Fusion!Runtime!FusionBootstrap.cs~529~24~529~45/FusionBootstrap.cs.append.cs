
    protected IEnumerator StartWithMppmVirtualInstance() {
      while (StartCommand.Instance == null) {
        yield return null;
      }
      
      var command = StartCommand.Instance;
      StartCommand.Instance = null;
      
      DefaultRoomName = command.RoomName;
      yield return StartClients(command.ClientCount, command.IsShared ? GameMode.Shared : GameMode.Client, command.InitialScene);
    }

    [EditorButton("Add Additional Client", EditorButtonVisibility.PlayMode)]
    [DrawIf(nameof(CanAddClients), Hide = true)]
    public void AddClient() {
      if (TryGetSceneRef(out var sceneRef)) {
        AddClient(GameMode.Client, sceneRef);
      }
    }

    [EditorButton("Add Additional Shared Client", EditorButtonVisibility.PlayMode)]
    [DrawIf(nameof(CanAddSharedClients), Hide = true)]
    public void AddSharedClient() {
      if (TryGetSceneRef(out var sceneRef)) {
        AddClient(GameMode.Shared, sceneRef);
      }
    }

    public Task AddClient(GameMode serverMode, SceneRef sceneRef) {
      var client = Instantiate(RunnerPrefab);
      DontDestroyOnLoad(client);

      client.name = $"Client {(Char)(65 + LastCreatedClientIndex++)}";

      // if server mode is Shared or AutoHostOrClient, then game client mode is the same as the server, otherwise it is client
      var mode = GameMode.Client;
      switch (serverMode) {
        case GameMode.Shared:
        case GameMode.AutoHostOrClient:
          mode = serverMode;
          break;
      }

#if FUSION_DEV
      var clientTask = InitializeNetworkRunner(client, mode, NetAddress.Any(), sceneRef, (runner) => {
        var name = client.name; // closures do not capture values, need a local var to save it
        Debug.Log($"Client NetworkRunner '{name}' started.");
      });
#else
      var clientTask = InitializeNetworkRunner(client, mode, NetAddress.Any(), sceneRef, null);
#endif

      return clientTask;
    }

    protected IEnumerator StartClients(int clientCount, GameMode serverMode, SceneRef sceneRef = default) {

      CurrentStage = Stage.ConnectingClients;

      var clientTasks = new List<Task>();
      for (int i = 0; i < clientCount; ++i) {
        clientTasks.Add(AddClient(serverMode, sceneRef));
        yield return new WaitForSeconds(ClientStartDelay);
      }

      var clientsStartTask = Task.WhenAll(clientTasks);

      while (clientsStartTask.IsCompleted == false) {
        yield return new WaitForSeconds(1f);
      }

      if (clientsStartTask.IsFaulted) {
        Debug.LogWarning(clientsStartTask.Exception);
      }

      CurrentStage = Stage.AllConnected;
    }

    protected virtual Task InitializeNetworkRunner(NetworkRunner runner, GameMode gameMode, NetAddress address, SceneRef scene, Action<NetworkRunner> onGameStarted, 
      INetworkRunnerUpdater updater = null) {

      var sceneManager = runner.GetComponent<INetworkSceneManager>();
      if (sceneManager == null) {
        Debug.Log($"NetworkRunner does not have any component implementing {nameof(INetworkSceneManager)} interface, adding {nameof(NetworkSceneManagerDefault)}.", runner);
        sceneManager = runner.gameObject.AddComponent<NetworkSceneManagerDefault>();
      }

      var objectProvider = runner.GetComponent<INetworkObjectProvider>();
      if (objectProvider == null) {
        Debug.Log($"NetworkRunner does not have any component implementing {nameof(INetworkObjectProvider)} interface, adding {nameof(NetworkObjectProviderDefault)}.", runner);
        objectProvider = runner.gameObject.AddComponent<NetworkObjectProviderDefault>();
      }

      var sceneInfo = new NetworkSceneInfo();
      if (scene.IsValid) {
        sceneInfo.AddSceneRef(scene, LoadSceneMode.Additive);
      }

      return runner.StartGame(new StartGameArgs {
        GameMode       = gameMode,
        Address        = address,
        Scene          = sceneInfo,
        SessionName    = DefaultRoomName,
        OnGameStarted    = onGameStarted,
        SceneManager   = sceneManager,
        Updater        = updater,
        ObjectProvider = objectProvider,
      });
    }
    
    private static bool IsMPPMEnabled => FusionMppm.Status != FusionMppmStatus.Disabled;
    
    /// <summary>
    /// Only show the GUI if the StartMode is set to UserInterface and not being run in a Virtual Instance (MPPM).
    /// </summary>
    public bool ShouldShowGUI => StartMode == StartModes.UserInterface &&
                                 !(AutoConnectVirtualInstances && FusionMppm.Status == FusionMppmStatus.VirtualInstance);
  }
}