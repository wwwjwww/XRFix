private IEnumerator ScanProjectFiles()
{
    m_IsAlreadyScanningProject = true;
    string packageFullPath = EditorUtilities.TMP_EditorUtility.packageFullPath;


    m_ProjectScanResults = k_ProjectScanReportDefaultText;
    m_ModifiedAssetList.Clear();
    m_ProgressPercentage = 0;


    if (m_ConversionData == null)
    m_ConversionData = JsonUtility.FromJson<AssetConversionData>(File.ReadAllText(packageFullPath + "/PackageConversionData.json"));


    string searchFolder = string.IsNullOrEmpty(m_ProjectFolderToScan) ? "Assets" : ("Assets/" + m_ProjectFolderToScan);
    string[] guids = AssetDatabase.FindAssets("t:Object", new string[] { searchFolder }).Distinct().ToArray();

    k_ProjectScanLabelPrefix = "<b>Phase 1 - Filtering:</b> ";
    m_ScanningTotalFiles = guids.Length;
    m_ScanningCurrentFileIndex = 0;

    List<AssetFileRecord> projectFilesToScan = new List<AssetFileRecord>();

    foreach (var guid in guids)
    {
        if (m_CancelScanProcess)
        break;

        string assetFilePath = AssetDatabase.GUIDToAssetPath(guid);

        m_ScanningCurrentFileIndex += 1;
        m_ScanningCurrentFileName = assetFilePath;
        m_ProgressPercentage = (float)m_ScanningCurrentFileIndex / m_ScanningTotalFiles;


        if (ShouldIgnoreFile(assetFilePath))
        continue;

        string assetMetaFilePath = AssetDatabase.GetTextMetaFilePathFromAssetPath(assetFilePath);

        projectFilesToScan.Add(new AssetFileRecord(assetFilePath, assetMetaFilePath));

        yield return null;
    }

    m_RemainingFilesToScan = m_ScanningTotalFiles = projectFilesToScan.Count;

    k_ProjectScanLabelPrefix = "<b>Phase 2 - Scanning:</b> ";

    var waitForSeconds = new WaitForSeconds(2.0f);

    for (int i = 0; i < m_ScanningTotalFiles; i++)
    {
        if (m_CancelScanProcess)
        break;

        AssetFileRecord fileRecord = projectFilesToScan[i];

        ThreadPool.QueueUserWorkItem(Task =>
        {
            ScanProjectFileAsync(fileRecord);

            m_ScanningCurrentFileName = fileRecord.assetFilePath;

            int completedScans = m_ScanningTotalFiles - Interlocked.Decrement(ref m_RemainingFilesToScan);

            m_ScanningCurrentFileIndex = completedScans;
            m_ProgressPercentage = (float)completedScans / m_ScanningTotalFiles;
        });

        if (i % 64 == 0)
        yield return waitForSeconds;

    }

    while (m_RemainingFilesToScan > 0 && !m_CancelScanProcess)
    yield return null;

    m_IsAlreadyScanningProject = false;
    m_ScanningCurrentFileName = string.Empty;
}
