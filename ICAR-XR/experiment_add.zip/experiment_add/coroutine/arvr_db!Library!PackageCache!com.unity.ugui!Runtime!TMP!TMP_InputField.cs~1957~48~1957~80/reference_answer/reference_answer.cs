IEnumerator Routine()
{
    var wait = new WaitForSeconds(0.1f);
    while (true)
    {
        // ... other logic
        yield return wait;
    }
}
