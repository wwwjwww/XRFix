using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using System.Text;
using System.Text.RegularExpressions;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.Serialization;

///         public virtual void OnDrag(PointerEventData eventData)
//         {
//             if (!MayDrag(eventData))
//                 return;
// 
//             CaretPosition insertionSide;
// 
//             int insertionIndex = TMP_TextUtilities.GetCursorIndexFromPosition(m_TextComponent, eventData.position, eventData.pressEventCamera, out insertionSide);
// 
//             if (m_isRichTextEditingAllowed)
//             {
//                 if (insertionSide == CaretPosition.Left)
//                 {
//                     stringSelectPositionInternal = m_TextComponent.textInfo.characterInfo[insertionIndex].index;
//                 }
//                 else if (insertionSide == CaretPosition.Right)
//                 {
//                     stringSelectPositionInternal = m_TextComponent.textInfo.characterInfo[insertionIndex].index + m_TextComponent.textInfo.characterInfo[insertionIndex].stringLength;
//                 }
//             }
//             else
//             {
//                 if (insertionSide == CaretPosition.Left)
//                 {
//                     stringSelectPositionInternal = insertionIndex == 0
//                         ? m_TextComponent.textInfo.characterInfo[0].index
//                         : m_TextComponent.textInfo.characterInfo[insertionIndex - 1].index + m_TextComponent.textInfo.characterInfo[insertionIndex - 1].stringLength;
//                 }
//                 else if (insertionSide == CaretPosition.Right)
//                 {
//                     stringSelectPositionInternal = m_TextComponent.textInfo.characterInfo[insertionIndex].index + m_TextComponent.textInfo.characterInfo[insertionIndex].stringLength;
//                 }
//             }
// 
//             caretSelectPositionInternal = GetCaretPositionFromStringIndex(stringSelectPositionInternal);
// 
//             MarkGeometryAsDirty();
// 
//             m_DragPositionOutOfBounds = !RectTransformUtility.RectangleContainsScreenPoint(textViewport, eventData.position, eventData.pressEventCamera);
//             if (m_DragPositionOutOfBounds && m_DragCoroutine == null)
//                 m_DragCoroutine = StartCoroutine(MouseDragOutsideRect(eventData));
// 
//             UpdateKeyboardStringPosition();
//             eventData.Use();
// 
//             #if TMP_DEBUG_MODE
//                 Debug.Log("Caret Position: " + caretPositionInternal + " Selection Position: " + caretSelectPositionInternal + "  String Position: " + stringPositionInternal + " String Select Position: " + stringSelectPositionInternal);
//             #endif
//         }
// 
//         IEnumerator MouseDragOutsideRect(PointerEventData eventData)
//         {
//             while (m_UpdateDrag && m_DragPositionOutOfBounds)
//             {
//                 Vector2 localMousePos;
// 
//                 RectTransformUtility.ScreenPointToLocalPointInRectangle(textViewport, eventData.position, eventData.pressEventCamera, out localMousePos);
// 
//                 Rect rect = textViewport.rect;
// 
//                 if (multiLine)
//                 {
//                     if (localMousePos.y > rect.yMax)
//                         MoveUp(true, true);
//                     else if (localMousePos.y < rect.yMin)
//                         MoveDown(true, true);
//                 }
//                 else
//                 {
//                     if (localMousePos.x < rect.xMin)
//                         MoveLeft(true, false);
//                     else if (localMousePos.x > rect.xMax)
//                         MoveRight(true, false);
//                 }
// 
//                 UpdateLabel();
// 
//                 float delay = multiLine ? kVScrollSpeed : kHScrollSpeed;
// 
//                 if (m_WaitForSecondsRealtime == null)
                    // BUG: Repetitive allocation of YieldInstruction in a loop
                    // MESSAGE: Finds the creation of new 'YieldInstruction' objects inside a loop within a coroutine. This pattern causes unnecessary GC pressure   and can lead to performance spikes, which is particularly detrimental in performance-sensitive applications like XR.
                    //                     m_WaitForSecondsRealtime = new WaitForSecondsRealtime(delay);

                    // Please allocate the YieldInstruction objects before the loop starts.
                    // FIXED CODE:
