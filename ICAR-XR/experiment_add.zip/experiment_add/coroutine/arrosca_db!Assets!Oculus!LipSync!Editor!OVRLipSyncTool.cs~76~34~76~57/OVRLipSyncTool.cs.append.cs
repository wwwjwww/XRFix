
    static OVRLipSyncToolLoader()
    {
        processor = null;
        EditorApplication.update += Update;
    }
    static void Update()
    {
        if (processor != null)
        {
            processor.MoveNext();
        }
    }
}

class OVRLipSyncTool
{
    [MenuItem("Oculus/Lip Sync/Generate Lip Sync Assets", false, 2000000)]
    static void GenerateLipSyncAssets()
    {
        GenerateLipSyncAssetsInternal(false);
    }

    [MenuItem("Oculus/Lip Sync/Generate Lip Sync Assets With Offline Model", false, 2500000)]
    static void GenerateLipSyncAssetsOffline()
    {
        GenerateLipSyncAssetsInternal(true);
    }

    private static void GenerateLipSyncAssetsInternal(bool useOfflineModel)

    {

        if (OVRLipSyncToolLoader.clipQueue == null)
        {
            OVRLipSyncToolLoader.clipQueue = new List<AudioClip>();
        }

        OVRLipSyncToolLoader.totalLengthOfClips = 0.0f;
        OVRLipSyncToolLoader.totalLengthOfClipsProcessed = 0.0f;

        for (int i = 0; i < Selection.objects.Length; ++i)
        {
            Object obj = Selection.objects[i];
            if (obj is AudioClip)
            {
                AudioClip clip = (AudioClip)obj;

                OVRLipSyncToolLoader.clipQueue.Add(clip);

                OVRLipSyncToolLoader.totalLengthOfClips += clip.length;
            }
        }

        OVRLipSyncToolLoader.processor = OVRLipSyncToolLoader.ProcessClips(useOfflineModel);
    }
}
