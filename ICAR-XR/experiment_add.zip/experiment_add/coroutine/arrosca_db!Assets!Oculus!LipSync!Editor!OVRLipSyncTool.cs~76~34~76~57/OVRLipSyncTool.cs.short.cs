using UnityEngine;
using UnityEditor;
using System.IO;
using System.Collections;
using System.Collections.Generic;

///     public static IEnumerator ProcessClips(bool useOfflineModel)
//     {
//         if (clipQueue == null || clipQueue.Count == 0)
//         {
//             yield break;
//         }
// 
//         while (clipQueue.Count > 0)
//         {
// 
//             AudioClip clip = clipQueue[0];
//             clipQueue.RemoveAt(0);
// 
//             if (clip.loadType != AudioClipLoadType.DecompressOnLoad)
//             {
//                 Debug.LogError(clip.name +
//                     ": Cannot process phonemes from an audio clip unless " +
//                     "its load type is set to DecompressOnLoad.");
//                 continue;
//             }
// 
// 
//             if (totalLengthOfClips > 0.0f)
//             {
//                 EditorUtility.DisplayProgressBar("Generating Lip Sync Assets...", "Processing clip " + clip.name + "...",
//                     totalLengthOfClipsProcessed / totalLengthOfClips);
//             }
// 
//             if (!clip.preloadAudioData)
//             {
//                 clip.LoadAudioData();
// 
//                 Debug.LogWarning(clip.name +
//                     ": Audio data is not pre-loaded. Data will be loaded then" +
//                     "unloaded on completion.");
// 
//                 while (clip.loadState != AudioDataLoadState.Loaded)
//                 {
                    // BUG: Repetitive allocation of YieldInstruction in a loop
                    // MESSAGE: Finds the creation of new 'YieldInstruction' objects inside a loop within a coroutine. This pattern causes unnecessary GC pressure   and can lead to performance spikes, which is particularly detrimental in performance-sensitive applications like XR.
                    //                     yield return new WaitForSeconds(0.1f);
                    //                 }
                    //             }
                    // 
                    //             var sequence =
                    //                 OVRLipSyncSequence.CreateSequenceFromAudioClip(clip, useOfflineModel);
                    //             if (sequence != null)
                    //             {
                    //                 var path = AssetDatabase.GetAssetPath(clip);
                    //                 var newPath = path.Replace(Path.GetExtension(path), "_lipSync.asset");
                    //                 var existingSequence = AssetDatabase.LoadAssetAtPath<OVRLipSyncSequence>(newPath);
                    //                 if (existingSequence != null)
                    //                 {
                    //                     EditorUtility.CopySerialized(sequence, existingSequence);
                    //                     AssetDatabase.SaveAssets();
                    //                 }
                    //                 else
                    //                 {
                    //                     AssetDatabase.CreateAsset(sequence, newPath);
                    // 
                    //                 }
                    //             }
                    //             AssetDatabase.Refresh();
                    // 
                    //             if (!clip.preloadAudioData)
                    //             {
                    //                 clip.UnloadAudioData();
                    //             }
                    // 
                    //             totalLengthOfClipsProcessed += clip.length;
                    //         }
                    // 
                    //         EditorUtility.ClearProgressBar();
                    //     }

                    // Please allocate the YieldInstruction objects before the loop starts.
                    // FIXED CODE:
