void Update()
{
    if (OVRInput.GetDown(OVRInput.RawButton.A))
    _ = SceneManagerHelper.RequestSceneCapture();
}

IEnumerator UpdateScenePeriodically()
{
    var waitForSeconds = new WaitForSeconds(UpdateFrequencySeconds);

    while (true)
    {
        yield return waitForSeconds;

        _updateSceneTask = UpdateScene();
        yield return new WaitUntil(() => _updateSceneTask.IsCompleted);
