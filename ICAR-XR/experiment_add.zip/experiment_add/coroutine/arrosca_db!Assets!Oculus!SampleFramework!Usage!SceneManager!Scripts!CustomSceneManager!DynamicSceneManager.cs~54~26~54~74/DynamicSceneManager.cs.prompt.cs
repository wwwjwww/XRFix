using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UnityEngine;
using DynamicSceneManagerHelper;


















public class DynamicSceneManager : MonoBehaviour
{
    public float UpdateFrequencySeconds = 5;

    SceneSnapshot _snapshot = new SceneSnapshot();
    Dictionary<OVRAnchor, GameObject> _sceneGameObjects = new Dictionary<OVRAnchor, GameObject>();

    Task _updateSceneTask;

    void Start()
    {
        SceneManagerHelper.RequestScenePermission();
        StartCoroutine(UpdateScenePeriodically());
    }

///     void Update()
//     {
//         if (OVRInput.GetDown(OVRInput.RawButton.A))
//             _ = SceneManagerHelper.RequestSceneCapture();
//     }
// 
//     IEnumerator UpdateScenePeriodically()
//     {
//         while (true)
//         {
//             yield return new WaitForSeconds(UpdateFrequencySeconds);
// 
//             _updateSceneTask = UpdateScene();
            // BUG: Repetitive allocation of YieldInstruction in a loop
            // MESSAGE: Finds the creation of new 'YieldInstruction' objects inside a loop within a coroutine. This pattern causes unnecessary GC pressure   and can lead to performance spikes, which is particularly detrimental in performance-sensitive applications like XR.
            //             yield return new WaitUntil(() => _updateSceneTask.IsCompleted);

            // Please allocate the YieldInstruction objects before the loop starts.
            // FIXED CODE:
