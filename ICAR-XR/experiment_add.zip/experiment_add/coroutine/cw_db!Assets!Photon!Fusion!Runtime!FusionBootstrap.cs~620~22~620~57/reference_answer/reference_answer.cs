protected IEnumerator StartClients(int clientCount, GameMode serverMode, SceneRef sceneRef = default) {

    CurrentStage = Stage.ConnectingClients;

    var clientTasks = new List<Task>();
    var waitForSeconds = new WaitForSeconds(ClientStartDelay);

    for (int i = 0; i < clientCount; ++i) {
        clientTasks.Add(AddClient(serverMode, sceneRef));
        yield return waitForSeconds;
    }

    var clientsStartTask = Task.WhenAll(clientTasks);

    while (clientsStartTask.IsCompleted == false) {
        yield return waitForSeconds;
    }

    if (clientsStartTask.IsFaulted) {
        Debug.LogWarning(clientsStartTask.Exception);
    }

    CurrentStage = Stage.AllConnected;
}
