namespace Fusion {
  using System;
  using Fusion.Sockets;
  using System.Collections;
  using System.Threading.Tasks;
  using UnityEngine;
  using UnityEngine.SceneManagement;
  using System.Collections.Generic;
  using System.Linq;
  using Statistics;
  using UnityEngine.Serialization;

#if UNITY_EDITOR
  using UnityEditor;
#endif





  [DisallowMultipleComponent]
  [AddComponentMenu("Fusion/Fusion Bootstrap")]
  [ScriptHelp(BackColor = ScriptHeaderBackColor.Steel)]
  public class FusionBootstrap : Fusion.Behaviour {




    public enum StartModes {
      UserInterface,
      Automatic,
      Manual
    }




    public enum Stage {
      Disconnected,
      StartingUp,
      UnloadOriginalScene,
      ConnectingServer,
      ConnectingClients,
      AllConnected,
    }

    [Serializable]
    class StartCommand : FusionMppmCommand {
      public string RoomName;
      public SceneRef InitialScene;
      public int ClientCount;
      public bool IsShared;

      public override void Execute() { 
        Instance = this;
      }

      public static StartCommand Instance;
    }






    [InlineHelp]
    [WarnIf(nameof(RunnerPrefab), false, "No " + nameof(RunnerPrefab) + " supplied. Will search for a " + nameof(NetworkRunner) + " in the scene at startup.")]
    public NetworkRunner RunnerPrefab;




    [InlineHelp]
    [WarnIf(nameof(StartMode), (long)StartModes.Manual, "Start network by calling the methods " + nameof(StartHost) + "(), " + nameof(StartServer) + "(), " + nameof(StartClient) + "(), " + nameof(StartHostPlusClients) + "(), or " + nameof(StartServerPlusClients) + "()")]
    public StartModes StartMode = StartModes.UserInterface;





    [InlineHelp]
    [UnityEngine.Serialization.FormerlySerializedAs("Server")]
    [DrawIf(nameof(StartMode), (long)StartModes.Automatic, Hide = true)]
    public GameMode AutoStartAs = GameMode.Shared;




    [InlineHelp]
    [DrawIf(nameof(StartMode), (long)StartModes.UserInterface, Hide = true)]
    public bool AutoHideGUI = true;





    [InlineHelp]
    [DrawIf(nameof(ShowAutoClients), Hide = true)]
    public int AutoClients = 1;




    [InlineHelp]
    public float ClientStartDelay = 0.1f;




    [InlineHelp]
    public ushort ServerPort; // Any port




    [InlineHelp]
    public string DefaultRoomName = string.Empty; // empty/null means Random Room Name

    [NonSerialized]
    NetworkRunner _server;





    [InlineHelp]
    [ScenePath]
    public string InitialScenePath;
    

    static string _initialScenePath;
    



    [InlineHelp]
    [SerializeField]
    [ReadOnly]
    protected Stage _currentStage;
    



    [DrawIf(nameof(IsMPPMEnabled), true)] 
    [Header("Multiplayer Play Mode")]
    public bool AutoConnectVirtualInstances = true;



    [DrawIf(nameof(IsMPPMEnabled), true)] 
    public float VirtualInstanceConnectDelay = 1f;
    



    public Stage CurrentStage {
      get => _currentStage;
      internal set {
        _currentStage = value;
#if UNITY_EDITOR

        EditorUtility.SetDirty(this);
#endif
      }
    }




    public int LastCreatedClientIndex { get; internal set; }




    public GameMode CurrentServerMode { get; internal set; }

    protected bool CanAddClients => CurrentStage == Stage.AllConnected && CurrentServerMode > 0 && CurrentServerMode != GameMode.Shared && CurrentServerMode != GameMode.Single;
    protected bool CanAddSharedClients => CurrentStage == Stage.AllConnected && CurrentServerMode > 0 && CurrentServerMode == GameMode.Shared;
    protected bool IsShutdown => CurrentStage == Stage.Disconnected;
    protected bool IsShutdownAndMultiPeer => CurrentStage == Stage.Disconnected && UsingMultiPeerMode;

    protected bool UsingMultiPeerMode => NetworkProjectConfig.Global.PeerMode == NetworkProjectConfig.PeerModes.Multiple;
    protected bool ShowAutoClients    => UsingMultiPeerMode && (StartMode == StartModes.UserInterface || (StartMode == StartModes.Automatic && AutoStartAs != GameMode.Single));


#if UNITY_EDITOR
    protected virtual void Reset() {
      if (TryGetComponent<FusionBootstrapDebugGUI>(out var ndsg) == false) {
        ndsg = gameObject.AddComponent<FusionBootstrapDebugGUI>();
      }
    }

#endif


    protected virtual void Start() {

      if (_initialScenePath == null) {
        if (string.IsNullOrEmpty(InitialScenePath)) {
          var currentScene = SceneManager.GetActiveScene();
          if (currentScene.IsValid()) {
            _initialScenePath = currentScene.path;
          } else {

            _initialScenePath = SceneManager.GetSceneByBuildIndex(0).path;
          }

          InitialScenePath = _initialScenePath;
        } else {
          _initialScenePath = InitialScenePath;
        }
      }

      var config      = NetworkProjectConfig.Global;
      var isMultiPeer = config.PeerMode == NetworkProjectConfig.PeerModes.Multiple;

      var existingRunner = FindFirstObjectByType<NetworkRunner>();

      if (existingRunner && existingRunner != RunnerPrefab) {
        if (existingRunner.State != NetworkRunner.States.Shutdown) {

          enabled = false;


          var gui = GetComponent<FusionBootstrapDebugGUI>();
          if (gui) {
            Destroy(gui);
          }

          Destroy(this);
          return;
        } else {

          if (RunnerPrefab == null) {
            RunnerPrefab = existingRunner;
          }
        }
      }

      if (FusionMppm.Status == FusionMppmStatus.VirtualInstance && AutoConnectVirtualInstances) {
        StartCoroutine(StartWithMppmVirtualInstance());
        return;
      }

      switch (StartMode) {
        case StartModes.Manual:

          return;
        case StartModes.Automatic: {
          if (TryGetSceneRef(out var sceneRef)) {
            int clientCount;
            if (AutoStartAs == GameMode.Single) {
              clientCount = 0;
            } else if (isMultiPeer) {
              clientCount = AutoClients;
            } else if (AutoStartAs == GameMode.Client || AutoStartAs == GameMode.Shared || AutoStartAs == GameMode.AutoHostOrClient) {
              clientCount = 1;
            } else {
              clientCount = 0;
            }

            StartCoroutine(StartWithClients(AutoStartAs, sceneRef, clientCount));
          }

          break;
        }
        default: {
          ShowUserInterface();
          break;
        }
      }
    }

    protected void ShowUserInterface() {
      if (TryGetComponent<FusionBootstrapDebugGUI>(out var gui) == false) {
        gui = gameObject.AddComponent<FusionBootstrapDebugGUI>();
      }
      gui.enabled = true;
    }
    
    private bool TryGetSceneRef(out SceneRef sceneRef) {
      var activeScene = SceneManager.GetActiveScene();
      if (activeScene.buildIndex < 0 || activeScene.buildIndex >= SceneManager.sceneCountInBuildSettings) {
        sceneRef = default;
        return false;
      } else {
        sceneRef = SceneRef.FromIndex(activeScene.buildIndex);
        return true;
      }
    }




    [EditorButton(EditorButtonVisibility.PlayMode)]
    [DrawIf(nameof(IsShutdown), Hide = true)]
    public virtual void StartSinglePlayer() {
      if (TryGetSceneRef(out var sceneRef)) {
        StartCoroutine(StartWithClients(GameMode.Single, sceneRef, 0));
      }
    }




    [EditorButton(EditorButtonVisibility.PlayMode)]
    [DrawIf(nameof(IsShutdown), Hide = true)]
    public virtual void StartServer() {
      if (TryGetSceneRef(out var sceneRef)) {
        StartCoroutine(StartWithClients(GameMode.Server, sceneRef, 0));
      }
    }




    [EditorButton(EditorButtonVisibility.PlayMode)]
    [DrawIf(nameof(IsShutdown), Hide = true)]
    public virtual void StartHost() {
      if (TryGetSceneRef(out var sceneRef)) {
        StartCoroutine(StartWithClients(GameMode.Host, sceneRef, 0));
      }
    }




    [EditorButton(EditorButtonVisibility.PlayMode)]
    [DrawIf(nameof(IsShutdown), Hide = true)]
    public virtual void StartClient() {
      StartCoroutine(StartWithClients(GameMode.Client, default, 1));
    }
    
    [EditorButton(EditorButtonVisibility.PlayMode)]
    [DrawIf(nameof(IsShutdown), Hide = true)]
    public virtual void StartSharedClient() {
      if (TryGetSceneRef(out var sceneRef)) {
        StartCoroutine(StartWithClients(GameMode.Shared, sceneRef, 1));
      }
    }
    
    [EditorButton("Start Auto Host Or Client", EditorButtonVisibility.PlayMode)]
    [DrawIf(nameof(IsShutdown), Hide = true)]
    public virtual void StartAutoClient() {
      if (TryGetSceneRef(out var sceneRef)) {
        StartCoroutine(StartWithClients(GameMode.AutoHostOrClient, sceneRef, 1));
      }
    }





    [EditorButton(EditorButtonVisibility.PlayMode)]
    [DrawIf(nameof(IsShutdown), Hide = true)]
    public virtual void StartServerPlusClients() {
      StartServerPlusClients(AutoClients);
    }





    [EditorButton(EditorButtonVisibility.PlayMode)]
    [DrawIf(nameof(IsShutdown), Hide = true)]
    public void StartHostPlusClients() {
      StartHostPlusClients(AutoClients);
    }

    [EditorButton(EditorButtonVisibility.PlayMode)]
    [DrawIf(nameof(CurrentStage), Hide = true)]
    public void Shutdown() {
      ShutdownAll();
    }





    public virtual void StartServerPlusClients(int clientCount) {
      if (NetworkProjectConfig.Global.PeerMode == NetworkProjectConfig.PeerModes.Multiple) {
        if (TryGetSceneRef(out var sceneRef)) {
          StartCoroutine(StartWithClients(GameMode.Server, sceneRef, clientCount));
        }
      } else {
        Debug.LogWarning($"Unable to start multiple {nameof(NetworkRunner)}s in Unique Instance mode.");
      }
    }





    public void StartHostPlusClients(int clientCount) {
      if (NetworkProjectConfig.Global.PeerMode == NetworkProjectConfig.PeerModes.Multiple) {
        if (TryGetSceneRef(out var sceneRef)) {
          StartCoroutine(StartWithClients(GameMode.Host, sceneRef, clientCount));
        }
      } else {
        Debug.LogWarning($"Unable to start multiple {nameof(NetworkRunner)}s in Unique Instance mode.");
      }
    }





    public void StartMultipleClients(int clientCount) {
      if (NetworkProjectConfig.Global.PeerMode == NetworkProjectConfig.PeerModes.Multiple) {
        if (TryGetSceneRef(out var sceneRef)) {
          StartCoroutine(StartWithClients(GameMode.Client, sceneRef, clientCount));
        }
      } else {
        Debug.LogWarning($"Unable to start multiple {nameof(NetworkRunner)}s in Unique Instance mode.");
      }
    }





    public void StartMultipleSharedClients(int clientCount) {
      if (NetworkProjectConfig.Global.PeerMode == NetworkProjectConfig.PeerModes.Multiple) {
        if (TryGetSceneRef(out var sceneRef)) {
          StartCoroutine(StartWithClients(GameMode.Shared, sceneRef, clientCount));
        }
      } else {
        Debug.LogWarning($"Unable to start multiple {nameof(NetworkRunner)}s in Unique Instance mode.");
      }
    }

    public void StartMultipleAutoClients(int clientCount) {
      if (NetworkProjectConfig.Global.PeerMode == NetworkProjectConfig.PeerModes.Multiple) {
        if (TryGetSceneRef(out var sceneRef)) {
          StartCoroutine(StartWithClients(GameMode.AutoHostOrClient, sceneRef, clientCount));
        }
      } else {
        Debug.LogWarning($"Unable to start multiple {nameof(NetworkRunner)}s in Unique Instance mode.");
      }
    }

    public void ShutdownAll() {
      foreach (var runner in NetworkRunner.Instances.ToList()) {
        if (runner != null && runner.IsRunning) {
          runner.Shutdown();
        }
      }

      SceneManager.LoadSceneAsync(_initialScenePath);

      Destroy(RunnerPrefab.gameObject);
      Destroy(gameObject);
      CurrentStage = Stage.Disconnected;
      CurrentServerMode = 0;
    }


    protected IEnumerator StartWithClients(GameMode serverMode, SceneRef sceneRef, int clientCount) {

      if (CurrentStage != Stage.Disconnected) {
        yield break;
      }

      bool includesServerStart = serverMode != GameMode.Shared && serverMode != GameMode.Client && serverMode != GameMode.AutoHostOrClient;

      if (!includesServerStart && clientCount == 0) {
        Debug.LogError($"{nameof(GameMode)} is set to {serverMode}, and {nameof(clientCount)} is set to zero. Starting no network runners.");
        yield break;
      }

      CurrentStage = Stage.StartingUp;

      var currentScene = SceneManager.GetActiveScene();


      if (!RunnerPrefab) {
        Debug.LogError($"{nameof(RunnerPrefab)} not set, can't perform debug start.");
        yield break;
      }


      RunnerPrefab = Instantiate(RunnerPrefab);
      DontDestroyOnLoad(RunnerPrefab);
      RunnerPrefab.name = "Temporary Runner Prefab";


      var config = NetworkProjectConfig.Global;
      if (config.PeerMode != NetworkProjectConfig.PeerModes.Multiple) {
        int maxClientsAllowed = includesServerStart ? 0 : 1;
        if (clientCount > maxClientsAllowed) {
          Debug.LogWarning($"Instance mode must be set to {nameof(NetworkProjectConfig.PeerModes.Multiple)} to perform a debug start multiple peers. Restricting client count to {maxClientsAllowed}.");
          clientCount = maxClientsAllowed;
        }
      }



      var localMultipeerCheck = (serverMode == GameMode.Shared || serverMode == GameMode.AutoHostOrClient || serverMode == GameMode.Server || serverMode == GameMode.Host) &&
                                clientCount     > 1                                                                                                                        &&
                                config.PeerMode == NetworkProjectConfig.PeerModes.Multiple;
      var isMppmMainInstance = FusionMppm.Status == FusionMppmStatus.MainInstance;
      
      if ((localMultipeerCheck || isMppmMainInstance) && string.IsNullOrEmpty(DefaultRoomName)) {
        DefaultRoomName = Guid.NewGuid().ToString();
        Debug.Log($"Generated Session Name: {DefaultRoomName}");
      }

      if (gameObject.transform.parent) {
        Debug.LogWarning($"{nameof(FusionBootstrap)} can't be a child game object, un-parenting.");
        gameObject.transform.parent = null;
      }

      DontDestroyOnLoad(gameObject);
      CurrentServerMode = serverMode;


      if (includesServerStart) {
        _server = Instantiate(RunnerPrefab);
        _server.name = serverMode.ToString();

        var serverTask = InitializeNetworkRunner(_server, serverMode, NetAddress.Any(ServerPort), sceneRef, (runner) => {
#if FUSION_DEV
          var name = _server.name; // closures do not capture values, need a local var to save it
          Debug.Log($"Server NetworkRunner '{name}' started.");
#endif
        });

        while (serverTask.IsCompleted == false) {
          yield return new WaitForSeconds(1f);
        }

        if (serverTask.IsFaulted) {
          Log.Debug($"Unable to start server: {serverTask.Exception}");

          ShutdownAll();
          yield break;
        }


        yield return StartClients(clientCount, serverMode, sceneRef);
      } else {
        yield return StartClients(clientCount, serverMode, sceneRef);
      }
      
      if (FusionMppm.Status == FusionMppmStatus.MainInstance && serverMode != GameMode.Single) {
        if (VirtualInstanceConnectDelay > 0) {
          yield return new WaitForSecondsRealtime(VirtualInstanceConnectDelay);
        }
        FusionMppm.MainEditor?.Send(new StartCommand {
          RoomName = DefaultRoomName,
          InitialScene = sceneRef,
          ClientCount =  1,
          IsShared = serverMode == GameMode.Shared
        });
      }
    }

    protected IEnumerator StartWithMppmVirtualInstance() {
      while (StartCommand.Instance == null) {
        yield return null;
      }
      
      var command = StartCommand.Instance;
      StartCommand.Instance = null;
      
      DefaultRoomName = command.RoomName;
      yield return StartClients(command.ClientCount, command.IsShared ? GameMode.Shared : GameMode.Client, command.InitialScene);
    }

    [EditorButton("Add Additional Client", EditorButtonVisibility.PlayMode)]
    [DrawIf(nameof(CanAddClients), Hide = true)]
    public void AddClient() {
      if (TryGetSceneRef(out var sceneRef)) {
        AddClient(GameMode.Client, sceneRef);
      }
    }

    [EditorButton("Add Additional Shared Client", EditorButtonVisibility.PlayMode)]
    [DrawIf(nameof(CanAddSharedClients), Hide = true)]
    public void AddSharedClient() {
      if (TryGetSceneRef(out var sceneRef)) {
        AddClient(GameMode.Shared, sceneRef);
      }
    }

    public Task AddClient(GameMode serverMode, SceneRef sceneRef) {
      var client = Instantiate(RunnerPrefab);
      DontDestroyOnLoad(client);

      client.name = $"Client {(Char)(65 + LastCreatedClientIndex++)}";


      var mode = GameMode.Client;
      switch (serverMode) {
        case GameMode.Shared:
        case GameMode.AutoHostOrClient:
          mode = serverMode;
          break;
      }

#if FUSION_DEV
      var clientTask = InitializeNetworkRunner(client, mode, NetAddress.Any(), sceneRef, (runner) => {
        var name = client.name; // closures do not capture values, need a local var to save it
        Debug.Log($"Client NetworkRunner '{name}' started.");
      });
#else
      var clientTask = InitializeNetworkRunner(client, mode, NetAddress.Any(), sceneRef, null);
#endif

      return clientTask;
    }

///     protected IEnumerator StartClients(int clientCount, GameMode serverMode, SceneRef sceneRef = default) {
// 
//       CurrentStage = Stage.ConnectingClients;
// 
//       var clientTasks = new List<Task>();
//       for (int i = 0; i < clientCount; ++i) {
//         clientTasks.Add(AddClient(serverMode, sceneRef));
        // BUG: Repetitive allocation of YieldInstruction in a loop
        // MESSAGE: Finds the creation of new 'YieldInstruction' objects inside a loop within a coroutine. This pattern causes unnecessary GC pressure   and can lead to performance spikes, which is particularly detrimental in performance-sensitive applications like XR.
        //         yield return new WaitForSeconds(ClientStartDelay);
        //       }
        // 
        //       var clientsStartTask = Task.WhenAll(clientTasks);
        // 
        //       while (clientsStartTask.IsCompleted == false) {
        //         yield return new WaitForSeconds(1f);
        //       }
        // 
        //       if (clientsStartTask.IsFaulted) {
        //         Debug.LogWarning(clientsStartTask.Exception);
        //       }
        // 
        //       CurrentStage = Stage.AllConnected;
        //     }

        // Please allocate the YieldInstruction objects before the loop starts.
        // FIXED CODE:
