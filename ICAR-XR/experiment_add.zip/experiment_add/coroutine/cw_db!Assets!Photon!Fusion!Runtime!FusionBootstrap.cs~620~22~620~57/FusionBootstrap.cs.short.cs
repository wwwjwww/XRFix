
///     protected IEnumerator StartClients(int clientCount, GameMode serverMode, SceneRef sceneRef = default) {
// 
//       CurrentStage = Stage.ConnectingClients;
// 
//       var clientTasks = new List<Task>();
//       for (int i = 0; i < clientCount; ++i) {
//         clientTasks.Add(AddClient(serverMode, sceneRef));
        // BUG: Repetitive allocation of YieldInstruction in a loop
        // MESSAGE: Finds the creation of new 'YieldInstruction' objects inside a loop within a coroutine. This pattern causes unnecessary GC pressure   and can lead to performance spikes, which is particularly detrimental in performance-sensitive applications like XR.
        //         yield return new WaitForSeconds(ClientStartDelay);
        //       }
        // 
        //       var clientsStartTask = Task.WhenAll(clientTasks);
        // 
        //       while (clientsStartTask.IsCompleted == false) {
        //         yield return new WaitForSeconds(1f);
        //       }
        // 
        //       if (clientsStartTask.IsFaulted) {
        //         Debug.LogWarning(clientsStartTask.Exception);
        //       }
        // 
        //       CurrentStage = Stage.AllConnected;
        //     }

        // Please allocate the YieldInstruction objects before the loop starts.
        // FIXED CODE:
