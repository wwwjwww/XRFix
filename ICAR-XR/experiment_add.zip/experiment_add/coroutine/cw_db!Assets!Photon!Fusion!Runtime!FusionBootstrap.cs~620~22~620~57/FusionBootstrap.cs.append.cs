
    protected virtual Task InitializeNetworkRunner(NetworkRunner runner, GameMode gameMode, NetAddress address, SceneRef scene, Action<NetworkRunner> onGameStarted, 
      INetworkRunnerUpdater updater = null) {

      var sceneManager = runner.GetComponent<INetworkSceneManager>();
      if (sceneManager == null) {
        Debug.Log($"NetworkRunner does not have any component implementing {nameof(INetworkSceneManager)} interface, adding {nameof(NetworkSceneManagerDefault)}.", runner);
        sceneManager = runner.gameObject.AddComponent<NetworkSceneManagerDefault>();
      }

      var objectProvider = runner.GetComponent<INetworkObjectProvider>();
      if (objectProvider == null) {
        Debug.Log($"NetworkRunner does not have any component implementing {nameof(INetworkObjectProvider)} interface, adding {nameof(NetworkObjectProviderDefault)}.", runner);
        objectProvider = runner.gameObject.AddComponent<NetworkObjectProviderDefault>();
      }

      var sceneInfo = new NetworkSceneInfo();
      if (scene.IsValid) {
        sceneInfo.AddSceneRef(scene, LoadSceneMode.Additive);
      }

      return runner.StartGame(new StartGameArgs {
        GameMode       = gameMode,
        Address        = address,
        Scene          = sceneInfo,
        SessionName    = DefaultRoomName,
        OnGameStarted    = onGameStarted,
        SceneManager   = sceneManager,
        Updater        = updater,
        ObjectProvider = objectProvider,
      });
    }
    
    private static bool IsMPPMEnabled => FusionMppm.Status != FusionMppmStatus.Disabled;
    
    /// <summary>
    /// Only show the GUI if the StartMode is set to UserInterface and not being run in a Virtual Instance (MPPM).
    /// </summary>
    public bool ShouldShowGUI => StartMode == StartModes.UserInterface &&
                                 !(AutoConnectVirtualInstances && FusionMppm.Status == FusionMppmStatus.VirtualInstance);
  }
}