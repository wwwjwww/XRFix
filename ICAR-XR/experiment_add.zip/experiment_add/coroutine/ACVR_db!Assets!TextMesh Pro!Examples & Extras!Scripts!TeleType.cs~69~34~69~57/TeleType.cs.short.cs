using UnityEngine;
using System.Collections;

///         void Awake()
//         {
// 
//             m_textMeshPro = GetComponent<TMP_Text>();
//             m_textMeshPro.text = label01;
//             m_textMeshPro.enableWordWrapping = true;
//             m_textMeshPro.alignment = TextAlignmentOptions.Top;
// 
// 
// 
// 
// 
// 
// 
// 
// 
// 
// 
// 
// 
// 
// 
//         }
// 
// 
//         IEnumerator Start()
//         {
// 
// 
//             m_textMeshPro.ForceMeshUpdate();
// 
// 
//             int totalVisibleCharacters = m_textMeshPro.textInfo.characterCount; // Get # of Visible Character in text object
//             int counter = 0;
//             int visibleCount = 0;
// 
//             while (true)
//             {
//                 visibleCount = counter % (totalVisibleCharacters + 1);
// 
//                 m_textMeshPro.maxVisibleCharacters = visibleCount; // How many characters should TextMeshPro display?
// 
// 
//                 if (visibleCount >= totalVisibleCharacters)
//                 {
//                     yield return new WaitForSeconds(1.0f);
//                     m_textMeshPro.text = label02;
                    // BUG: Repetitive allocation of YieldInstruction in a loop
                    // MESSAGE: Finds the creation of new 'YieldInstruction' objects inside a loop within a coroutine. This pattern causes unnecessary GC pressure   and can lead to performance spikes, which is particularly detrimental in performance-sensitive applications like XR.
                    //                     yield return new WaitForSeconds(1.0f);

                    // Please allocate the YieldInstruction objects before the loop starts.
                    // FIXED CODE:
