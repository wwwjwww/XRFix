﻿using UnityEngine;
using System.Collections;


namespace TMPro.Examples
{
    
    public class ShaderPropAnimator : MonoBehaviour
    {

        private Renderer m_Renderer;
        private Material m_Material;

        public AnimationCurve GlowCurve;

        public float m_frame;

        void Awake()
        {
            m_Renderer = GetComponent<Renderer>();
            m_Material = m_Renderer.material;
            waitForEndOfFrame = new WaitForEndOfFrame();
        }

///         void Start()
//         {
//             StartCoroutine(AnimateProperties());
//         }
// 
//         IEnumerator AnimateProperties()
//         {
// 
//             float glowPower;
//             m_frame = Random.Range(0f, 1f);
// 
//             while (true)
//             {
// 
// 
// 
//                 glowPower = GlowCurve.Evaluate(m_frame);
//                 m_Material.SetFloat(ShaderUtilities.ID_GlowPower, glowPower);
// 
//                 m_frame += Time.deltaTime * Random.Range(0.2f, 0.3f);
                // BUG: Repetitive allocation of YieldInstruction in a loop
                // MESSAGE: Finds the creation of new 'YieldInstruction' objects inside a loop within a coroutine. This pattern causes unnecessary GC pressure   and can lead to performance spikes, which is particularly detrimental in performance-sensitive applications like XR.
                //                 yield return new WaitForEndOfFrame();

                // Please allocate the YieldInstruction objects before the loop starts.
                // FIXED CODE:


private YieldInstruction waitForEndOfFrame;

        void Start()
        {
            StartCoroutine(AnimateProperties());
        }



        IEnumerator AnimateProperties()
        {
            //float lightAngle;
            float glowPower;
            m_frame = Random.Range(0f, 1f);

            while (true)
            {
                //lightAngle = (m_Material.GetFloat(ShaderPropertyIDs.ID_LightAngle) + Time.deltaTime) % 6.2831853f;
                //m_Material.SetFloat(ShaderPropertyIDs.ID_LightAngle, lightAngle);

                glowPower = GlowCurve.Evaluate(m_frame);
                m_Material.SetFloat(ShaderUtilities.ID_GlowPower, glowPower);

                m_frame += Time.deltaTime * Random.Range(0.2f, 0.3f);
                yield return new WaitForEndOfFrame();
            }
        }
    }
}
