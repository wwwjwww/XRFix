void Start()
{
    StartCoroutine(AnimateProperties());
    waitForEndOfFrame = new WaitForEndOfFrame();
}

IEnumerator AnimateProperties()
{

    float glowPower;
    m_frame = Random.Range(0f, 1f);

    while (true)
    {

        glowPower = GlowCurve.Evaluate(m_frame);
        m_Material.SetFloat(ShaderUtilities.ID_GlowPower, glowPower);

        m_frame += Time.deltaTime * Random.Range(0.2f, 0.3f);
        yield return waitForEndOfFrame;
