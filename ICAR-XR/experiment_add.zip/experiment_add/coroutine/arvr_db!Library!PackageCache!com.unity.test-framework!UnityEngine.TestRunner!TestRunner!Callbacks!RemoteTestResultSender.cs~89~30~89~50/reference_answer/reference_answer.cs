public IEnumerator SendDataRoutine()
{
    var waitForSeconds = new WaitForSeconds(1);

    while (!PlayerConnection.instance.isConnected)
    {
        yield return waitForSeconds;
    }

    while (true)
    {
        lock (m_LockQueue)
        {
            if (m_SendQueue.Count > 0)
            {
                if (PlayerConnection.instance.isConnected)
                {
                    ResetNextPlayerAliveMessageTime();
                    var queueData = m_SendQueue.Dequeue();
                    PlayerConnection.instance.Send(queueData.id, queueData.data);
                }

                yield return null;
            }
            else //This is needed so we dont stall the player totally
            {
                SendAliveMessageIfNeeded();
                yield return waitForSeconds;
            }
        }
    }
}
