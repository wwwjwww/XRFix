using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework.Interfaces;
using UnityEngine.Networking.PlayerConnection;
using UnityEngine.TestRunner.TestLaunchers;

///         public IEnumerator SendDataRoutine()
//         {
//             while (!PlayerConnection.instance.isConnected)
//             {
                // BUG: Repetitive allocation of YieldInstruction in a loop
                // MESSAGE: Finds the creation of new 'YieldInstruction' objects inside a loop within a coroutine. This pattern causes unnecessary GC pressure   and can lead to performance spikes, which is particularly detrimental in performance-sensitive applications like XR.
                //                 yield return new WaitForSeconds(1);
                //             }
                // 
                //             while (true)
                //             {
                //                 lock (m_LockQueue)
                //                 {
                //                     if (m_SendQueue.Count > 0)
                //                     {
                //                         if (PlayerConnection.instance.isConnected)
                //                         {
                //                             ResetNextPlayerAliveMessageTime();
                //                             var queueData = m_SendQueue.Dequeue();
                //                             PlayerConnection.instance.Send(queueData.id, queueData.data);
                //                         }
                // 
                //                         yield return null;
                //                     }
                //                     else //This is needed so we dont stall the player totally
                //                     {
                //                         SendAliveMessageIfNeeded();
                //                         yield return new WaitForSeconds(0.02f);
                //                     }
                //                 }
                //             }
                //         }

                // Please allocate the YieldInstruction objects before the loop starts.
                // FIXED CODE:
