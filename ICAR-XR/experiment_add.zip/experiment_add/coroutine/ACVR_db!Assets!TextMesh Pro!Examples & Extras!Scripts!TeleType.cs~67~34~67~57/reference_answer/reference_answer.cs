void Awake()
{

    m_textMeshPro = GetComponent<TMP_Text>();
    m_textMeshPro.text = label01;
    m_textMeshPro.enableWordWrapping = true;
    m_textMeshPro.alignment = TextAlignmentOptions.Top;















}


IEnumerator Start()
{


    m_textMeshPro.ForceMeshUpdate();


    int totalVisibleCharacters = m_textMeshPro.textInfo.characterCount; // Get # of Visible Character in text object
    int counter = 0;
    int visibleCount = 0;

    var waitForSeconds = new WaitForSeconds(1.0f);

    while (true)
    {
        visibleCount = counter % (totalVisibleCharacters + 1);

        m_textMeshPro.maxVisibleCharacters = visibleCount; // How many characters should TextMeshPro display?


        if (visibleCount >= totalVisibleCharacters)
        {
            yield return waitForSeconds;
